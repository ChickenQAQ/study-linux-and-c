#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/fb.h>
#include <linux/kd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <stdbool.h>

#include <jpeglib.h>
#include <jerror.h>

#include "jpg.h"

char *jpg2rgb(const char *jpgdata, size_t jpgsize, struct jpg_size *jpginfo)
    {
        struct jpeg_decompress_struct cinfo;
        struct jpeg_error_mgr jerr;

        cinfo.err = jpeg_std_error(&jerr);
        jpeg_create_decompress(&cinfo);

        jpeg_mem_src(&cinfo, jpgdata, jpgsize);

        if(!jpeg_read_header(&cinfo, true))
        {
            fprintf(stderr, "jpeg_read_header failed: %s\n", strerror(errno));
            return NULL;
        }
        cinfo.out_color_space = JCS_RGB;
        jpeg_start_decompress(&cinfo);

        jpginfo->width = cinfo.output_width;
        jpginfo->height = cinfo.output_height;

        int linesize = cinfo.output_width * cinfo.num_components;
        unsigned long rgbsize  = (unsigned long)linesize * cinfo.output_height;
        char *rgbdata = calloc(1, rgbsize);

        while(cinfo.output_scanline < cinfo.output_height)
        {
            unsigned char *buffer_array[1];
            buffer_array[0] = (unsigned char *)(rgbdata + cinfo.output_scanline * linesize);
            jpeg_read_scanlines(&cinfo, buffer_array, 1);
        }

        jpeg_finish_decompress(&cinfo);
        jpeg_destroy_decompress(&cinfo);

        return rgbdata;
    }

bool showjpg(char *p, struct lcd_size *lcdinfo, struct jpg_size *jpginfo, char *jpg)
{
    FILE *fp = fopen(jpg, "rb");
    if(fp == NULL)
    {
        fprintf(stderr, "open %s failed: %s\n", jpg, strerror(errno));
        return false;
    }
    fseek(fp, 0, SEEK_END);
    long jpgsize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char *jpgdata = malloc(jpgsize);
    fread(jpgdata, 1, jpgsize, fp);
    fclose(fp);

    char *rgbdata = jpg2rgb(jpgdata, jpgsize, jpginfo);
    if(rgbdata == NULL)
    {
        fprintf(stderr, "jpg2rgb failed\n");
        free(jpgdata);
        return false;
    }

    int fb_w = lcdinfo->width;
    int fb_h = lcdinfo->height;
    int fb_bpp = lcdinfo->bpp;
    int fb_byte = fb_bpp / 8;

    int rgb_w = jpginfo->width;
    int rgb_h = jpginfo->height;
    const int rgb_bpp = 3;

    int x = (fb_w - rgb_w) / 2;
    if(x < 0) x = 0;
    int y = (fb_h - rgb_h) / 2;
    if(y < 0) y = 0;

    for(int i = 0; i < rgb_h && i < fb_h; i++)
    {
        int lcd_offset = (y + i) * fb_w * fb_byte + x * fb_byte;
        int rgb_offset = i * rgb_w * rgb_bpp;
        for(int j = 0; j < rgb_w && j < fb_w; j++)
        {
            char *lcd = p + lcd_offset + j * fb_byte;
            memcpy(lcd, rgbdata + rgb_offset + j * rgb_bpp, rgb_bpp);
            char tmp = lcd[0];
            lcd[0] = lcd[2];
            lcd[2] = tmp;
        }
    }
    free(jpgdata);
    free(rgbdata);
    return true;
}